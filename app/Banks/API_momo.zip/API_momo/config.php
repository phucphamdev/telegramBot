<?php
	$config = [
		'appVer' => '40024',
		'appCode' => "4.0.2",
		'token' => "GhiGiCungDuocMienDu32KiTuLaDuocc",
		'isVoice' => true,
	];
	
	$userInfo = [
		"phone" => "",
		"password" => "",
	]
?>