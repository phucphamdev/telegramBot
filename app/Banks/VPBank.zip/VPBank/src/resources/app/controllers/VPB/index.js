const listBank = require('../../../modules/VPB/listBank');

class VPBController {
    // [GET]/ list-bank
    getListBank(req, res) {
        handleSuccess(res, 'Danh sách ngân hàng !', listBank);
    }

    async getListTransaction(req, res) {
        const { api } = res.locals;
        const { time } = req.body;

        try {
            const { id } = await api.getBalance();
            const transaction = await api.getTransaction(id, time);

            handleSuccess(
                res,
                'Lấy lịch sử giao dịch thành công !',
                transaction
            );
        } catch (error) {
            handleError(res, 'Lỗi lấy lịch sử giao dịch !', error);
        }
    }

    async getBalance(req, res) {
        const { api } = res.locals;
        try {
            const { balance } = await api.getBalance();

            handleSuccess(res, 'Lấy số dư thành công ! ', balance);
        } catch (error) {
            handleError(res, 'Lỗi lấy số dư !', error);
        }
    }

    async postVerifyTransfer(req, res) {
        const { api } = res.locals;
        const { code, accountNo, text, amount } = req.body;
        try {
            const id = await api.getSourceProductListRequest();

            const { name } = await api.checkBank(id, {
                code,
                accountNo,
            });

            if (!name) {
                handleError(res, 'Lỗi thết lập chuyển khoản !', error);
                return;
            }

            await api.verifyTransfer(id, name, accountNo, text, amount);
            await api.nextVerifyTransfer(id, name, accountNo);
            const exeId = api.param.getExeId();
            handleSuccess(res, 'Thiết lập chuyển khoản thành công !', {
                id,
                exeId,
            });
        } catch (error) {
            handleError(res, 'Lỗi thết lập chuyển khoản !', error);
        }
    }

    async postConfirmTransfer(req, res) {
        const { api } = res.locals;
        const { id, otp, exeId } = req.body;
        try {
            api.param.setExeId(exeId);
            const bank = await api.confirmTransfer(id, otp);

            handleSuccess(res, 'Chuyển tiền thành công !');
        } catch (error) {
            handleError(res, 'Chuyển tiền không thành công !', error);
        }
    }
}

function handleSuccess(res, msg, data = '') {
    res.json({
        isSuccess: 1,
        msg,
        data,
    });
}

function handleError(res, msg, data = '') {
    res.status(500).json({
        isSuccess: 0,
        msg,
        data,
    });
}

module.exports = new VPBController();
