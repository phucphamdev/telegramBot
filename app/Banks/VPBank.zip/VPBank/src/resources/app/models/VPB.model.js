const { Schema, model } = require('mongoose');

const VPB = new Schema(
    {
        user: {
            type: String,
            require: true,
        },
        pass: {
            type: String,
            require: true,
        },
        session: {
            type: String,
            require: true,
        },
    },
    {
        timestamps: true,
    }
);

VPB.index({ createdAt: 1 }, { expireAfterSeconds: 360 });

module.exports = model('VPB', VPB);
