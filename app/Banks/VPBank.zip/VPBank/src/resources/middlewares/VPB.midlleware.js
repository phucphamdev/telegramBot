const VPBModel = require('../app/models/VPB.model');
const VPBModule = require('../modules/VPB/module');

module.exports.isLogin = async (req, res, next) => {
    const { user, pass } = req.body;
    try {
        if (!user || !pass) {
            handleError(res, 'Vui lòng nhập tài khoản và mật khẩu !');
            return;
        }

        const api = new VPBModule(user, pass);
        const check = await VPBModel.findOne({ user, pass });

        if (!check) {
            await api.getOperationState();
            await api.login();
            const session = api.getSession();

            await VPBModel.findOneAndUpdate(
                {
                    user,
                    pass,
                },
                {
                    session,
                },
                {
                    upsert: true,
                    new: true,
                    setDefaultsOnInsert: true,
                }
            );
        } else {
            api.setSession(check.session);
        }

        res.locals.api = api;
        next();
    } catch (error) {
        console.log(error);
        handleError(res, 'Lỗi đăng nhập !');
    }
};

function handleError(res, msg, data = '') {
    res.status(500).json({
        isSuccess: 0,
        msg,
        data,
    });
}
