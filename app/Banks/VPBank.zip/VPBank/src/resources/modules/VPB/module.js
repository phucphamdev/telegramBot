let rq = require('request-promise');

const fs = require('fs');

const xml2js = require('xml2js').parseStringPromise;

const param = require('./param');

rq = rq.defaults({
    headers: {
        'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36)',
        'mb-app-version': '2.10.16',
        'Content-Type': 'application/gzip',
    },
});

const formatMoney = text => {
    const [money, value] = text.split('E');
    if (!value) return Number(text);
    return Number(money) * Number(`1E${value}`);
};

class VPB {
    constructor(user, pass) {
        this.user = user;
        this.pass = pass;
        this.session = null;
        this.param = new param(user, pass);
    }

    getSession() {
        return this.session;
    }

    setSession(session) {
        this.session = session;
    }

    async getOperationState(type = 'login') {
        try {
            const res = await this.requestServer(
                this.param.operationState(type)
            );
            const op = res.map.map[0].map[0].list[1].map[9].string[11];

            this.param.setOT(op);

            return Promise.resolve(true);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async login() {
        try {
            const res = await this.requestServer(this.param.login());
            let stepId = res.map.map[0].map[0].string[3];
            // console.log(res.map.map[0].map[0]);
            if (stepId === 'loginPasswordStep') return Promise.reject(false);
            const op = res.map.map[0].map[0].list[1].map[2].string[11];
            this.param.setOT(op);
            // let result = 'otp';
            // if (stepId === 'endStep') result = 'nootp';
            return Promise.resolve(op);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async getBalance() {

        try {
            const res = await this.requestServer(
                this.param.getProductListRequest()
            );

            const data = res.map.map[0].list[0].map[0];
            return Promise.resolve({
                accountNo: data.string[1],
                id: data.string[18],
                balance: data.double[0],
            });
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async getSourceProductListRequest() {
        try {
            const res = await Promise.all([
                this.requestServer(this.param.getSourceProductListRequest()),
                this.requestServer(
                    this.param.operationState('transferToAccount')
                ),
            ]);
            
            const id = res[0].map.map[0].list[0].map[0].string[10];
            const exeIdTrans = res[1].map.map[0].map[0].string[5];
            this.param.setExeId(exeIdTrans);
            return Promise.resolve(id);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async checkBank(id, targetBank) {
        try {
            const res = await this.requestServer(
                this.param.checkBank(id, targetBank)
            );
            //fs.writeFileSync('test.json', JSON.stringify(res));
            const name = res.map.map[0].map[0].list[1].map[14].string[12];
            return Promise.resolve({name, accountNo: targetBank.accountNo});
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async verifyTransfer(id, name, accountNo, text, amount) {
        try {
            const res = await this.requestServer(
                this.param.verifyTransfer(id, name, accountNo, text, amount)
            );

            return Promise.resolve(true);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async nextVerifyTransfer(id, name, accountNo) {
        try {
            await this.requestServer(
                this.param.nextVerifyTransfer(id, name, accountNo)
            );

            return Promise.resolve(true);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async confirmTransfer(id, otp) {
        try {
            const res = await this.requestServer(
                this.param.confirmTransfer(id, otp)
            );

            const check = res.map.map[0].map[0].string[3];
            if (check === 'finalStep') return Promise.resolve(true);

            return Promise.reject(false);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async getTransaction(id, timeGet) {
        try {
            //dd/mm/yyyy

            const data = await this.requestServer(
                this.param.getTransaction(id, timeGet)
            );

            const temp = data.map.map[0].list[0].map;
            // console.log(data.map.map[0]);
            let amount = '';
            let time = '';
            if (!temp) return Promise.resolve([]);

            const transaction = temp.map(item => {
                if (item.ref) {
                    time = item.map[1].map[0].int;
                    amount = formatMoney(item.map[2].double[0]);

                } else {
                    time = item.map[2].map[0].int;
                    amount = formatMoney(item.map[4].double[0]);
                }
                time = time.reverse().join('/');

                const codeTransfer = item.string[7];
                const content = item.string[9];

                return {codeTransfer, content, amount, time};
            });

            let res = transaction.reduce((preV, curV) => {
                preV[curV.time] = preV[curV.time] || [];
                preV[curV.time].unshift(curV);
                return preV;
            }, Object.create({}));

            let result = Object.keys(res).reduce((preV, curV) => {
                return preV.concat(res[curV]);
            }, []);

            return Promise.resolve(result.reverse());
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async confirmOTP(otp) {
        try {
            const res = await this.requestServer(this.param.confirmOTP(otp));
            fs.writeFileSync('test1.json', JSON.stringify(res));
            let stepId = res.map.map[0].map[0].string[3];

            if (stepId === 'newPinStep') return Promise.resolve(true);
            return Promise.reject(stepId);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    requestServer(body) {
        return new Promise(async (resolve, reject) => {
            try {
                const options = {
                    uri: 'https://uiux.vpbank.com.vn/endpoint/envelope',
                    method: 'POST',
                    headers: {
                        Cookie: this.session,
                    },
                    body,
                    transform: (res, response) => {
                        const setCookie = response.headers['set-cookie'];
                        const session = setCookie.map(item => {
                            const temp = item.split(';');
                            return temp[0];
                        });
                        return {
                            res,
                            session: session.join('; '),
                        };
                    },
                };
                let {res, session} = await rq(options);
                if (this.session === null) this.session = session;

                res = await xml2js(res);
                resolve(res);
            } catch (error) {
                reject(error);
            }
        });
    }
}

module.exports = VPB;
