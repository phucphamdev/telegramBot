const { Router } = require('express');

const controller = require('../../app/controllers/VPB');
const middleware = require('../../middlewares/VPB.midlleware');

const router = Router();

router.get('/list-bank', controller.getListBank);

router.use(middleware.isLogin);

router.post('/get-transaction', controller.getListTransaction);

router.post('/get-balance', controller.getBalance);

router.post('/verify-transfer', controller.postVerifyTransfer);

router.post('/confirm-transfer', controller.postConfirmTransfer);

module.exports = router;
