require('dotenv').config();
const mongoose = require('mongoose');

//const HOST = process.env.DB_HOST;
//const PORT = process.env.DB_PORT;
const DB_NAME = process.env.DB_NAME;
const DB_URI = process.env.DB_URI;

module.exports.connect = async () => {
    try {
        await mongoose.connect(DB_URI, {
            dbName: DB_NAME,
            useCreateIndex: true,
            useFindAndModify: false,
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('Connect database successfully !');
    } catch (error) {
        console.log(error);
        console.log(`Connect database failure !`);
    }
};
