require('dotenv').config();
const express = require('express');

const db = require('./resources/config/db');
const route = require('./resources/routes');

const app = express();
const PORT = process.env.PORT;

//Connect database
db.connect();

app.use(express.json());

route(app);

app.listen(PORT, () => {
    console.log(`Listen on port ${PORT}`);
});
