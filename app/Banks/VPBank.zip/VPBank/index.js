const VPBRoute = require('./VPB');

const route = app => {
    app.use('/vpb', VPBRoute);
};

module.exports = route;
