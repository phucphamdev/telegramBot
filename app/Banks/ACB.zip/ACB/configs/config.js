module.exports = {
    port: 7002,
    db_host: 'localhost',
    db_port: 3306,
    db_user: 'root',
    db_password: '',
    db_database: 'acb',
    captcha_service: 'twocaptcha',
    captcha_key: ['c668ae146516be44009aac0252761fca']
}